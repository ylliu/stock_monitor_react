// App.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import StockTable from './components/StockTable';
import StockConfig from './components/StockConfig';
const mockStockData = [
  { id: 1, code: '000001', name: 'Tencent', price: 500.0 },
  { id: 2, code: '000002', name: 'Alibaba', price: 300.0 },
];

function App() {
  return (
    <div>
      <h1>Stock Monitor</h1>
      <StockConfig />
      <StockTable stocks={mockStockData} />
    </div>
  );
}

export default App;