// StockTable.js
import React from 'react';

const StockTable = ({ stocks }) => {
  return (
    <table className="table table-striped table-hover">
      <thead className="thead-dark">
        <tr>
          <th scope="col">Stock Code</th>
          <th scope="col">Stock Name</th>
          <th scope="col">Current Price</th>
        </tr>
      </thead>
      <tbody>
        {stocks.map((stock) => (
          <tr key={stock.id}>
            <td>{stock.code}</td>
            <td>{stock.name}</td>
            <td>{stock.price}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default StockTable;